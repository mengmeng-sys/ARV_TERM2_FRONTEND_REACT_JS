import Navbar from "../components/Navbar"
import Footer from "../components/Footer"
function AboutPage(){
 return(
  <>
  <Navbar/>
   <p>hello from About page</p>
   <Footer/>
  </>
 )
}
export default AboutPage;